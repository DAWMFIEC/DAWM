// URL del modelo exportado desde Teachable Machine
const URL = "";

let model, labelContainer, maxPredictions, imgElement;

// Función para cargar el modelo de Teachable Machine
async function init() {
    const modelURL = URL + "model.json"; // URL del archivo del modelo
    const metadataURL = URL + "metadata.json"; // URL del archivo de metadatos

    // Cargar el modelo y los metadatos
    model = await tmImage.load(modelURL, metadataURL);
    maxPredictions = model.getTotalClasses(); // Obtener el número total de clases del modelo

    // Preparar el contenedor para mostrar las etiquetas y sus probabilidades
    labelContainer = document.getElementById("label-container");
    for (let i = 0; i < maxPredictions; i++) {
        labelContainer.appendChild(document.createElement("div")); // Crear un div por cada clase
    }
}

// Función para realizar la predicción sobre una imagen cargada
async function predict() {
    // La función predict puede tomar un elemento HTML de tipo imagen, video o canvas
    const prediction = await model.predict(imgElement); // Realizar la predicción usando la imagen cargada
    for (let i = 0; i < maxPredictions; i++) {
        // Crear una cadena con el nombre de la clase y su probabilidad
        const classPrediction = prediction[i].className + ": " + prediction[i].probability.toFixed(2);
        labelContainer.childNodes[i].innerHTML = classPrediction; // Mostrar la predicción en el contenedor
    }
}

// Función para cargar una imagen desde el input de archivo
function loadImage() {
    // Manejar el evento de cambio en el input de tipo file
    document.getElementById("image-input").addEventListener("change", async (event) => {
        const file = event.target.files[0]; // Obtener el archivo seleccionado
        if (file) {
            imgElement = document.createElement("img"); // Crear un elemento de imagen dinámicamente

            const reader = new FileReader(); // Crear un objeto FileReader para leer el archivo
            // Manejar el evento onload para cuando el archivo ha sido leído completamente
            reader.onload = (e) => {
                imgElement.src = e.target.result; // Asignar la imagen cargada como fuente (base64)
                imgElement.style.display = "block"; // Asegurarse de que la imagen sea visible
            };

            reader.readAsDataURL(file); // Leer el archivo como una URL en formato base64

            // Añadir la imagen cargada al contenedor del DOM
            const imageContainer = document.getElementById("image-container");
            imageContainer.innerHTML = ""; // Limpiar cualquier imagen previa en el contenedor
            imageContainer.appendChild(imgElement); // Agregar la nueva imagen

            // Reiniciar las etiquetas de predicción para que queden vacías
            for (let i = 0; i < maxPredictions; i++) {
                labelContainer.childNodes[i].innerHTML = ""; // Limpiar las predicciones previas
            }
        }
    });
}

// Función para inicializar las funciones necesarias al cargar la página
loadFunctions = () => {
    init(); // Cargar el modelo
    loadImage(); // Configurar la funcionalidad de carga de imágenes
}

// Ejecutar las funciones necesarias cuando el DOM haya sido completamente cargado
window.addEventListener("DOMContentLoaded", loadFunctions);
