<?php

	$recipient = "Your_Email@example.com"; // Note: Please replace this email with your recipient's email

?>