function holaMundo() {
	console.logg("Hola, mundo!")
}

holaMundo()