function ejecutarFunciones() {
    byId()
    byClass()
    byTagName()
    querySelector()
}

ejecutarFunciones()