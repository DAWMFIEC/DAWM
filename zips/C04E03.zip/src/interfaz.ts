interface Person {
    ssn: string;
    firstName: string;
    lastName: string; 
    age: number;
    married: boolean;   
}

let interfazPropiedades = () => {

	/* Inicio */
	//Defina la variable person del tipo Person
	
	/* Fin */

	return person
}

console.log(interfazPropiedades())

export {interfazPropiedades}