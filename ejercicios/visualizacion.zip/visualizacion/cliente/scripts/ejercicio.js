let socket = io("ws://localhost:3000");
 
let registros = []

//Al ocurrir un mensaje nuevo. (Revise el evento 'new' emitido por el servidor en servidor/index.js)
socket.on('new', (data) => {


    registros.push(data)

    let plantillaRow = ``


    for (var i = 0; i < registros.length - 1; i++) {

        let inicio = registros[i]
        let fin = registros[i+1]

        plantillaRow += `
            <tr>
                <td style="--start: ${inicio.value}; --size: ${fin.value}"> <span class="data"> ${fin.value} </span> </td>
            </tr>
        `
    }


   
    document.getElementsByTagName('tbody')[0].innerHTML = `<tbody>`+plantillaRow+`</tbody>` 
   
   
    if (registros.length > 20) {
        registros.shift()
    }


})
