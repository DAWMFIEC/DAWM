const pokeAPIURL = "https://pokeapi.co/api/v2/pokemon?limit=151&offset=0"

/**
 * Instrucciones para generar el código de `loadPokedex`:
 *
 * 1. Definea la función flecha loadPokedex. 
 * 2. Llame a la función loadPokedex cuando el documento esté completamente cargado.
 * 3. Dentro de loadPokedex:
 *
 *    3.1 Realice una solicitud asincrónica a la URL en la constante `pokeAPIURL`
 *    3.2 Verifique si existe un OK en la respuesta. 
 *      3.2.1. En caso de no ser existir el OK: muestre un mensaje de alerta con el texto 'No existen datos en el pokedex'
 *      3.2.2. En caso de existir el OK:
 * 
 *          3.2.2.1. Convierta la respuesta a JSON
 *          3.2.2.2. Extraiga el arreglo de la clave 'results' e itere sobre el arreglo. Por cada elemento:
 *                   
 *          Complete la variable img con el índice del elemento actual. 
 *          
 *          IDX = <INDICE-ARREGLO>+1
 *          let img = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/<IDX>.png`
 *          
 *          Complete la variable template con los datos del pokemon actual 
 * 
 *          let template = `
                    <div class="col-md-2">
                        <div class="card p-2 my-2">
                            <img src="<IMG>" class="card-img-top" alt="<NAME>">
                                <div class="card-body">
                                <h5 class="card-title text-center"> <NAME> </h5>
                                </div>
                        </div>
                    </div>`
 *                    
 *           3.2.2.3. Actualice el elemento HTML con el id listofpokemons con la variable template. 
 *     3.3. En caso de cualquier otro error, muestre un mensaje de alerta con el texto 'Sin conexión'
 */

