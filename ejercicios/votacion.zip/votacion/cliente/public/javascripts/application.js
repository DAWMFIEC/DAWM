window.addEventListener('DOMContentLoaded', (event) => {
 peticion()
});


let peticion = async () => {

	let promesa = await fetch(window.location.origin+'/servidor/jugadores.json')
	let data = await promesa.json()
	let shuffled = data.sort((a, b) => 0.5 - Math.random())

	let plantilla = ``  	

  	shuffled.forEach(jugador => {
  		plantilla = `
	  		<div class="col">
	          <div class="card h-100">
	            <img src="${jugador.img}" class="card-img-top" alt="...">
	            <div class="card-body">
	              <h5 class="card-title">${jugador.short_name}</h5>
	              Votos: <span id="votos-${jugador.sofifa_id}">0</span>
	            </div>
	            <div class="card-footer bg-transparent text-center">
	            	<a id="${jugador.sofifa_id}" href="#" class="btn btn-primary">Votar</a>
	            </div>
	          </div>
	        </div>
	  	`

	  	document.getElementById('jugadores').innerHTML += plantilla


  	})


  	Array.from(document.querySelectorAll("a.btn")).forEach( a => { 

  		a.addEventListener("click", (ev) => {
  			let idPlayer = ev.target.id
  			alert(idPlayer)
  		})

  	})





}