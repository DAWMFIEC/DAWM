const URL = 'https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits?per_page=100'

let peticion = async (event) => {

	console.time('Tiempo de ejecución del fetch')

	// Bloque de petición - Inicio

	document.getElementById("respuesta").innerHTML = ''

	let respuesta = await fetch(URL, { cache: 'no-cache' });
	let obj = await respuesta.json()

	document.getElementById("respuesta").innerHTML = obj.length + ' registros';

	// Bloque de petición - Fin

	console.timeEnd('Tiempo de ejecución del fetch')
	 
}

window.onload = function () {
  

  document.getElementById('cargar').addEventListener('click', peticion )
  

}