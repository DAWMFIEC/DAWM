var socket = io("ws://localhost:3000");

window.addEventListener('DOMContentLoaded', (event) => {
 peticion()
});


socket.on('votacion', (data) => { 
	let votaciones = new Map(Object.entries(data))

	votaciones.forEach((value, key) => {
		document.getElementById(`votos-`+key).innerText = value
	}) 
})

let peticion = async () => {

	let promesa = await fetch('http://localhost:8001/jugadores.json')
	let data = await promesa.json()
	let shuffled = data.sort((a, b) => 0.5 - Math.random())

	let plantilla = ``  	

  	shuffled.forEach(jugador => {
  		plantilla = `
	  		<div class="col">
	          <div class="card h-100">
	            <img src="${jugador.img}" class="card-img-top" alt="...">
	            <div class="card-body">
	              <h5 class="card-title">${jugador.short_name}</h5>
	              Votos: <span id="votos-${jugador.sofifa_id}">0</span>
	            </div>
	            <div class="card-footer bg-transparent text-center">
	            	<a id="${jugador.sofifa_id}" href="#" class="btn btn-primary">Votar</a>
	            </div>
	          </div>
	        </div>
	  	`

	  	document.getElementById('jugadores').innerHTML += plantilla


  	})


  	Array.from(document.querySelectorAll("a.btn")).forEach( a => { 

  		a.addEventListener("click", (ev) => {
  			let idPlayer = ev.target.id

  			let voto = { 'jugadorID': idPlayer }
  			socket.emit('votar', voto)

  		})

  	})





}