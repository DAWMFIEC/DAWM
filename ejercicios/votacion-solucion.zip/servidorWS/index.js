const Server  = require("socket.io").Server;

const votaciones = new Map()

const io = new Server(3000, { 
    cors: {
        origin: '*'
    }
});





io.on("connection", (socket) => {

   console.log("conectado!")
   io.emit('votacion', Object.fromEntries(votaciones)  );


   socket.on("votar" , (data) => {
    
        let jugadorID = data['jugadorID']
        let votos = votaciones.has(jugadorID)? votaciones.get(jugadorID) + 1: 1;
        votaciones.set(jugadorID, votos)

        console.log(votaciones)

        io.emit('votacion', Object.fromEntries(votaciones) );
        
   })
   
});



